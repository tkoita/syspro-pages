/* reader.c : 自分の mystery ファイルを読むプログラム（雛形）
 *   TODO と書いてあるところを，自分で調べた結果に合わせて書き換える */
#include <stdio.h>
#include <stdint.h>     /* int16_t, int32_t, int64_t を使うため */
#include <fcntl.h>
#include <unistd.h>

struct record {
    /* TODO: od で調べた順番と大きさで，4つの項目を並べる
     *   例）int32_t number;  char name[12];  int64_t time;  float value;  */
};

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "使い方: %s ファイル名\n", argv[0]);
        return 1;
    }
    int fd = open(argv[1], O_RDONLY);
    if (fd == -1) { perror(argv[1]); return 1; }

    printf("sizeof(struct record) = %zu\n", sizeof(struct record));

    struct record r;
    int count = 0;
    while (read(fd, &r, sizeof r) == sizeof r) {
        count++;
        /* TODO: 1件分を表示する（番号・名前・時刻・気温） */
    }
    printf("件数: %d\n", count);
    /* TODO: 欠番と，気温がいちばん高い場所も表示する */

    close(fd);
    return 0;
}
