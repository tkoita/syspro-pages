/* practice_reader.c : 練習用ファイル practice.dat を読む見本 */
#include <stdio.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>

struct record {             /* practice.dat の1件の形（仕様書どおり） */
    int32_t number;         /* 番号 */
    char    name[8];        /* 場所の名前（後ろは \0 で埋まっている） */
    double  value;          /* 気温 */
};

int main(int argc, char *argv[])
{
    struct record r;
    const char *path = (argc > 1) ? argv[1] : "practice.dat";   /* 引数がなければ practice.dat */
    int fd = open(path, O_RDONLY);
    if (fd == -1) { perror(path); return 1; }

    printf("1件の大きさ sizeof(struct record) = %zu バイト\n", sizeof(struct record));
    while (read(fd, &r, sizeof r) == sizeof r)     /* 1件ずつ読む */
        printf("%d  %-8s  %.2f\n", r.number, r.name, r.value);

    close(fd);
    return 0;
}
