/* stdcp.c : 1文字ずつコピーする．ただし read/write ではなく getc/putc（標準入出力ライブラリ）を使う */
#include <stdio.h>

int main(int argc, char *argv[])
{
    if (argc != 3) {
        fprintf(stderr, "使い方: %s コピー元 コピー先\n", argv[0]);
        return 1;
    }
    FILE *in = fopen(argv[1], "rb");
    if (in == NULL) { perror(argv[1]); return 1; }
    FILE *out = fopen(argv[2], "wb");
    if (out == NULL) { perror(argv[2]); return 1; }

    int c;
    while ((c = getc(in)) != EOF)   /* 1文字ずつ読んで */
        putc(c, out);               /* 1文字ずつ書く */

    fclose(in);
    fclose(out);
    return 0;
}
