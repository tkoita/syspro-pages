/* bufcp.c : バッファの大きさを指定してファイルをコピーする */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc != 4) {
        fprintf(stderr, "使い方: %s コピー元 コピー先 バッファの大きさ\n", argv[0]);
        return 1;
    }
    long size = atol(argv[3]);
    if (size < 1) {
        fprintf(stderr, "バッファの大きさは1以上にしてください\n");
        return 1;
    }
    char *buf = malloc(size);
    if (buf == NULL) { perror("malloc"); return 1; }

    int in = open(argv[1], O_RDONLY);
    if (in == -1) { perror(argv[1]); return 1; }
    int out = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (out == -1) { perror(argv[2]); return 1; }

    /* TODO（問1-2）: ここに read と write の回数を数える変数を用意する */
    ssize_t n;
    while ((n = read(in, buf, size)) > 0) {
        if (write(out, buf, n) != n) { perror("write"); return 1; }
    }
    if (n == -1) { perror("read"); return 1; }

    /* TODO（問1-2）: 回数を標準エラー出力に表示する */
    close(in);
    close(out);
    free(buf);
    return 0;
}
