#!/bin/bash
# measure.sh : バッファの大きさを変えながら bufcp の時間を測る
for size in 1 4 16 64 256 1024 4096 16384 65536 262144 1048576
do
    for i in 1 2 3
    do
        echo "=== size=$size  ${i}回目 ==="
        time ./bufcp big.dat copy.dat $size
    done
done
